Millennium Outpatient Standing Orders CCL Module (SODB)
Written by Andy Krull: andy.krull@albertahealthservices.ca

Summary:  This module allows for storing standing order requisitions in custom tables within Millennium.  Our environment uses immediate discharge outpatient encounters, as well as outpatient clinics with open encounters from our HIS.
Access:  Users access this module from exporer menu.  A couple of CCLs are run from Operations Jobs for maintenance.

Terms of use:  Please feel free to use this source code compliments of Alberta Health Services - no whole or part of this module is to be sold/resold.  
		This module was presented at CRUG 2013.

Deploying into your environment:
1)  Two custom tables will be created in your environment (cust_sodb & cust_sodb_ord).  You will need a separate user account and table space in Oracle (separate from V500).  For reference, ours is 'AHSCCL'.
	You will need to modify the .SQL code to reference this user & table space when you create your tables - failure to put this in a place that is distinct from V500 runs the risk of losing data when a revision upgrade is performed.
	Once the tables are created, you will need to run oragen3 "Your_User.CUST_SODB" go and oragen3 "Your_User.CUST_SODB_ORD" go on each app node from the back-end.  This defines the CCL tables.
	In addition to the custom tables, indexes and a sequence is created in Oracle as well.
2) This module uses the 4003 code_set for frequencies.  *Caution as this is a shared code set with pharmacy.  
	PHADBFREQ.EXE will give you access to maintian frequencies.  Customization will need to be done in the object lab_oe_sodb_freq.prg if you wish to view/modify the frequencies.
	I have configured all of our frequencies in days duration for simplicity.  Calculations in lab_oe_sodb_freq.prg are based on days.  Updates will be needed if you use anything else.  
3) Our Reporting Priorities might be different from yours: check lab_oe_sodb_pri.prg and modify as required.
4) We will definitely have different aliases for our providers.  You will need to modify quite a few alias variables throughout the code.  We use two aliases.  Moving to one alias will require a few re-writes.
5) Order catalog customizations will be required based on your build.  Have a look at lab_oe_sodb_ord_cat.prg
6) We use linking to encounters - we only do this for pcis/HIS encounter aliases (we have an external HIS: SCM).  You may want to customize the encounter aliases for your needs.
7) PMSearch (person search) is executed from the Explorer Menu/DVDev.  If it looks different from DOE person search, you will need to customize it the same way you have it in DOE.  Look at your config in DOE (right click) and set it identically in EM/DVDev.  Your core analyst can help you here.

Best of Luck - if you do deploy this, please post back and let me know that.  If you find improvements/enhancements, please share your findings!


--CCL/SQL Objects & Description--

***Table Creation***
SQL_TABLE_CREATION.SQL - This is to be run in Oracle directly, then use oragen3 to define CCL tables on each app node.  We define tables with Oracle SQL directly because we found that indexes & ownership failed with CCL table creation.  When Indexes are created successfully in CCL, they are created in V500.  
			It is strongly advised not to use V500 table space due to risk of revision upgrade data loss.  I do have the table defined with documentation in CCL, however, I advise against using it!  indexes fail when an owner is defined.
lab_oe_sodb_table_creation.ccl - This should not be used, use the above .sql to generate the table.  This is of value for reference with table design.  


***Core Functionality***
lab_oe_sodb.prg - Function published in Explorer Menu; allows users to add/modify/inactivate a patient's standing order requisition.  
		This is a complex prompt and object.  A lot of the prompts fields call CCL objects (ccl_prompt_api_dataset) to pull data.  Using separate API_DATASET objects permits ease of maintenance and improved portability between environments.
		The object handles inserting new records into the SODB custom tables.  The method of record lifecycle is similar to Cerner tables.  Updates insert a new record with active_ind=1, previous records are inactivated (active_ind=0).
		Prompt code uses Javascript to control prompt display, add in custom functionality, and utilize Millennium native functions (PMSearch/person search).
		Only one active requisition is permitted for a given patient, provider, and frequency.
		Order catalog data seems to come in pre-selected on the first item when using accession capture or updating an existing SODB record.  Users will need to unselect it.

lab_oe_sodb_psc_print.prg - Function is published in Explorer Menu: allows lab collectors to search for the patient's SODB requisition, then print it.
			
lab_oe_sodb_search.prg - Function is published in Explorer Menu: allows users to search the SODB tables in a flexible way and also comprehensively search for duplicate tests ordered on a patient on different frequencies.


***Maintenance CCLs***
lab_oe_sodb_prv_updt.prg - Function is published in Explorer Menu: allows users to perform a mass update on active SODB records.  This is important when we have a change to a provider (physicial retires, what do we do with all the existing SODB requisitions).  
				Users can re-assign to a new provider, or inactivate the SODB requisitions & remove Cc entries on that provider.

lab_oe_sodb_test_updt.prg - Function is published in Explorer Menu:  allows users to perform a mass update on active SODB records.  This is important when we have a rebuild/inactivation in the order catalog.  Users can remove/update the test (optionally based on reporting priority). 

lab_oe_sodb_prsn_cmb.prg - Function is run from an operations job every morning: applies person combines to the SODB tables.  !This does not work with uncombines!  You will need to explore & expand to accommodate for that.

lab_oe_sodb_auto_cancel.prg - Function is run from an operations job every morning:  job inactivates SODB records if end date<curdate, or if there is no activity for 1.5 years.

lab_oe_sodb_ops.prg - Object is an execute wrapper for the above to for running in Ops.  Using this is optional


***Reporting***
lab_oe_sodb_statistics.prg - Function is published in Explorer Menu:  allows management to see the number of manually modified records (excludes ops jobs & mass updates).



***Supporting Objects***
lab_oe_sodb_req_l.dvt - Layout object that displays the requisition for printing.  Object is called from lab_oe_sodb & lab_oe_sodb_psc_print.  An SODB_ID is passed as a prompt variable.  Preprocessing code is used to capture any SODB records that are soon expiring.  This is done to provide patient & physician renewal reminders on the requisition.

lab_oe_sodb_ord_prv.prg - prompt api_dataset: delivers ordering provider data to the prompt.

lab_oe_sodb_freq.prg - 	prompt api_dataset: delivers frequencies available for the standing order.

lab_oe_sodb_ord_cat.prg - prompt api_dataset: delivers the order catalog data.  The data is captured from manual entry, then also by accession entry/sodb_id entry as well.

lab_oe_sodb_pri.prg - prompt api_dataset: delivers available priorities for the standing order database.

lab_oe_sodb_phone.prg - prompt api_dataset: delivers any phone/contact info stored in millennium for a given provider.

lab_oe_sodb_pcis_enc.prg - prompt api_dataset: delivers PCIS/HIS encounters (based on appropriate aliases).

lab_oe_sodb_cc_prv.prg - prompt api_dataset: delivers Cc providers that are available for selection.  This is a prompt window that is integrated with Javascript to work correctly.

lab_oe_sodb_so_found.prg - prompt api_dataset: delivers a value to a hidden prompt to note if an active SODB record exists.  If the value is returned true, Javascript delivers a pop-up msg to that effect.

lab_oe_sodb_dup_tests.prg - prompt api_dataset: delivers a quick couple of audits to lab_oe_sodb.prg.  This allows SODB data entry staff to see duplicate tests on a patient.  

lab_oe_sodb_text.prg - used in the prompt but this is a CCL called from Javascript.  This CCL is used to capture text data from an existing SODB record and Javascript updates the prompt value with the text.

lab_oe_sodb_security.prg - Security object executed from lab_oe_sodb.prg, lab_oe_sodb_test_updt.prg, and lab_oe_sodb_prv_updt.prg.  Offers security based on userID & environment.  We couldn't use Explorer Menu due to our organization size.