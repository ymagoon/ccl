/*
    http://www.JSON.org/json2.js
    2010-03-20

    Public Domain.

    NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

    See http://www.JSON.org/js.html


    This code should be minified before deployment.
    See http://javascript.crockford.com/jsmin.html

    USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
    NOT CONTROL.


    This file creates a global JSON object containing two methods: stringify
    and parse.

        JSON.stringify(value, replacer, space)
            value       any JavaScript value, usually an object or array.

            replacer    an optional parameter that determines how object
                        values are stringified for objects. It can be a
                        function or an array of strings.

            space       an optional parameter that specifies the indentation
                        of nested structures. If it is omitted, the text will
                        be packed without extra whitespace. If it is a number,
                        it will specify the number of spaces to indent at each
                        level. If it is a string (such as '\t' or '&nbsp;'),
                        it contains the characters used to indent at each level.

            This method produces a JSON text from a JavaScript value.

            When an object value is found, if the object contains a toJSON
            method, its toJSON method will be called and the result will be
            stringified. A toJSON method does not serialize: it returns the
            value represented by the name/value pair that should be serialized,
            or undefined if nothing should be serialized. The toJSON method
            will be passed the key associated with the value, and this will be
            bound to the value

            For example, this would serialize Dates as ISO strings.

                Date.prototype.toJSON = function (key) {
                    function f(n) {
                        // Format integers to have at least two digits.
                        return n < 10 ? '0' + n : n;
                    }

                    return this.getUTCFullYear()   + '-' +
                         f(this.getUTCMonth() + 1) + '-' +
                         f(this.getUTCDate())      + 'T' +
                         f(this.getUTCHours())     + ':' +
                         f(this.getUTCMinutes())   + ':' +
                         f(this.getUTCSeconds())   + 'Z';
                };

            You can provide an optional replacer method. It will be passed the
            key and value of each member, with this bound to the containing
            object. The value that is returned from your method will be
            serialized. If your method returns undefined, then the member will
            be excluded from the serialization.

            If the replacer parameter is an array of strings, then it will be
            used to select the members to be serialized. It filters the results
            such that only members with keys listed in the replacer array are
            stringified.

            Values that do not have JSON representations, such as undefined or
            functions, will not be serialized. Such values in objects will be
            dropped; in arrays they will be replaced with null. You can use
            a replacer function to replace those with JSON values.
            JSON.stringify(undefined) returns undefined.

            The optional space parameter produces a stringification of the
            value that is filled with line breaks and indentation to make it
            easier to read.

            If the space parameter is a non-empty string, then that string will
            be used for indentation. If the space parameter is a number, then
            the indentation will be that many spaces.

            Example:

            text = JSON.stringify(['e', {pluribus: 'unum'}]);
            // text is '["e",{"pluribus":"unum"}]'


            text = JSON.stringify(['e', {pluribus: 'unum'}], null, '\t');
            // text is '[\n\t"e",\n\t{\n\t\t"pluribus": "unum"\n\t}\n]'

            text = JSON.stringify([new Date()], function (key, value) {
                return this[key] instanceof Date ?
                    'Date(' + this[key] + ')' : value;
            });
            // text is '["Date(---current time---)"]'


        JSON.parse(text, reviver)
            This method parses a JSON text to produce an object or array.
            It can throw a SyntaxError exception.

            The optional reviver parameter is a function that can filter and
            transform the results. It receives each of the keys and values,
            and its return value is used instead of the original value.
            If it returns what it received, then the structure is not modified.
            If it returns undefined then the member is deleted.

            Example:

            // Parse the text. Values that look like ISO date strings will
            // be converted to Date objects.

            myData = JSON.parse(text, function (key, value) {
                var a;
                if (typeof value === 'string') {
                    a =
/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
                    if (a) {
                        return new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4],
                            +a[5], +a[6]));
                    }
                }
                return value;
            });

            myData = JSON.parse('["Date(09/09/2001)"]', function (key, value) {
                var d;
                if (typeof value === 'string' &&
                        value.slice(0, 5) === 'Date(' &&
                        value.slice(-1) === ')') {
                    d = new Date(value.slice(5, -1));
                    if (d) {
                        return d;
                    }
                }
                return value;
            });


    This is a reference implementation. You are free to copy, modify, or
    redistribute.
*/

/*jslint evil: true, strict: false */

/*members "", "\b", "\t", "\n", "\f", "\r", "\"", JSON, "\\", apply,
    call, charCodeAt, getUTCDate, getUTCFullYear, getUTCHours,
    getUTCMinutes, getUTCMonth, getUTCSeconds, hasOwnProperty, join,
    lastIndex, length, parse, prototype, push, replace, slice, stringify,
    test, toJSON, toString, valueOf
*/


// Create a JSON object only if one does not already exist. We create the
// methods in a closure to avoid creating global variables.

if (!this.JSON) {
    this.JSON = {};
}

(function () {

    function f(n) {
        // Format integers to have at least two digits.
        return n < 10 ? '0' + n : n;
    }

    if (typeof Date.prototype.toJSON !== 'function') {

        Date.prototype.toJSON = function (key) {

            return isFinite(this.valueOf()) ?
                   this.getUTCFullYear()   + '-' +
                 f(this.getUTCMonth() + 1) + '-' +
                 f(this.getUTCDate())      + 'T' +
                 f(this.getUTCHours())     + ':' +
                 f(this.getUTCMinutes())   + ':' +
                 f(this.getUTCSeconds())   + 'Z' : null;
        };

        String.prototype.toJSON =
        Number.prototype.toJSON =
        Boolean.prototype.toJSON = function (key) {
            return this.valueOf();
        };
    }

    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        gap,
        indent,
        meta = {    // table of character substitutions
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"' : '\\"',
            '\\': '\\\\'
        },
        rep;


    function quote(string) {

// If the string contains no control characters, no quote characters, and no
// backslash characters, then we can safely slap some quotes around it.
// Otherwise we must also replace the offending characters with safe escape
// sequences.

        escapable.lastIndex = 0;
        return escapable.test(string) ?
            '"' + string.replace(escapable, function (a) {
                var c = meta[a];
                return typeof c === 'string' ? c :
                    '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
            }) + '"' :
            '"' + string + '"';
    }


    function str(key, holder) {

// Produce a string from holder[key].

        var i,          // The loop counter.
            k,          // The member key.
            v,          // The member value.
            length,
            mind = gap,
            partial,
            value = holder[key];

// If the value has a toJSON method, call it to obtain a replacement value.

        if (value && typeof value === 'object' &&
                typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }

// If we were called with a replacer function, then call the replacer to
// obtain a replacement value.

        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }

// What happens next depends on the value's type.

        switch (typeof value) {
        case 'string':
            return quote(value);

        case 'number':

// JSON numbers must be finite. Encode non-finite numbers as null.

            return isFinite(value) ? String(value) : 'null';

        case 'boolean':
        case 'null':

// If the value is a boolean or null, convert it to a string. Note:
// typeof null does not produce 'null'. The case is included here in
// the remote chance that this gets fixed someday.

            return String(value);

// If the type is 'object', we might be dealing with an object or an array or
// null.

        case 'object':

// Due to a specification blunder in ECMAScript, typeof null is 'object',
// so watch out for that case.

            if (!value) {
                return 'null';
            }

// Make an array to hold the partial results of stringifying this object value.

            gap += indent;
            partial = [];

// Is the value an array?

            if (Object.prototype.toString.apply(value) === '[object Array]') {

// The value is an array. Stringify every element. Use null as a placeholder
// for non-JSON values.

                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || 'null';
                }

// Join all of the elements together, separated with commas, and wrap them in
// brackets.

                v = partial.length === 0 ? '[]' :
                    gap ? '[\n' + gap +
                            partial.join(',\n' + gap) + '\n' +
                                mind + ']' :
                          '[' + partial.join(',') + ']';
                gap = mind;
                return v;
            }

// If the replacer is an array, use it to select the members to be stringified.

            if (rep && typeof rep === 'object') {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    k = rep[i];
                    if (typeof k === 'string') {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            } else {

// Otherwise, iterate through all of the keys in the object.

                for (k in value) {
                    if (Object.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (gap ? ': ' : ':') + v);
                        }
                    }
                }
            }

// Join all of the member texts together, separated with commas,
// and wrap them in braces.

            v = partial.length === 0 ? '{}' :
                gap ? '{\n' + gap + partial.join(',\n' + gap) + '\n' +
                        mind + '}' : '{' + partial.join(',') + '}';
            gap = mind;
            return v;
        }
    }

// If the JSON object does not yet have a stringify method, give it one.

    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function (value, replacer, space) {

// The stringify method takes a value and an optional replacer, and an optional
// space parameter, and returns a JSON text. The replacer can be a function
// that can replace values, or an array of strings that will select the keys.
// A default replacer method can be provided. Use of the space parameter can
// produce text that is more easily readable.

            var i;
            gap = '';
            indent = '';

// If the space parameter is a number, make an indent string containing that
// many spaces.

            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) {
                    indent += ' ';
                }

// If the space parameter is a string, it will be used as the indent string.

            } else if (typeof space === 'string') {
                indent = space;
            }

// If there is a replacer, it must be a function or an array.
// Otherwise, throw an error.

            rep = replacer;
            if (replacer && typeof replacer !== 'function' &&
                    (typeof replacer !== 'object' ||
                     typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }

// Make a fake root object containing our value under the key of ''.
// Return the result of stringifying the value.

            return str('', {'': value});
        };
    }


// If the JSON object does not yet have a parse method, give it one.

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text, reviver) {

// The parse method takes a text and an optional reviver function, and returns
// a JavaScript value if the text is a valid JSON text.

            var j;

            function walk(holder, key) {

// The walk method is used to recursively walk the resulting structure so
// that modifications can be made.

                var k, v, value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver.call(holder, key, value);
            }


// Parsing happens in four stages. In the first stage, we replace certain
// Unicode characters with escape sequences. JavaScript handles many characters
// incorrectly, either silently deleting them, or treating them as line endings.

            text = String(text);
            cx.lastIndex = 0;
            if (cx.test(text)) {
                text = text.replace(cx, function (a) {
                    return '\\u' +
                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }

// In the second stage, we run the text against regular expressions that look
// for non-JSON patterns. We are especially concerned with '()' and 'new'
// because they can cause invocation, and '=' because it can cause mutation.
// But just to be safe, we want to reject all unexpected forms.

// We split the second stage into 4 regexp operations in order to work around
// crippling inefficiencies in IE's and Safari's regexp engines. First we
// replace the JSON backslash pairs with '@' (a non-JSON character). Second, we
// replace all simple value tokens with ']' characters. Third, we delete all
// open brackets that follow a colon or comma or that begin the text. Finally,
// we look to see that the remaining characters are only whitespace or ']' or
// ',' or ':' or '{' or '}'. If that is so, then the text is safe for eval.

            if (/^[\],:{}\s]*$/.
test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@').
replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').
replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {

// In the third stage we use the eval function to compile the text into a
// JavaScript structure. The '{' operator is subject to a syntactic ambiguity
// in JavaScript: it can begin a block or an object literal. We wrap the text
// in parens to eliminate the ambiguity.

                j = eval('(' + text + ')');

// In the optional fourth stage, we recursively walk the new structure, passing
// each name/value pair to a reviver function for possible transformation.

                return typeof reviver === 'function' ?
                    walk({'': j}, '') : j;
            }

// If the text is not JSON parseable, then a SyntaxError is thrown.

            throw new SyntaxError('JSON.parse');
        };
    }
}());

var MPage;
if (typeof MPage == "undefined") {
    MPage = {
        _Components: [],
        Properties: {
            mine: "mine",
            personId: 0.0,
            encounter: 0.0,
            userId: 0.0,
            pprCd: 0.0,
            posCd: 0.0,
			appNum: 0.0
        },
        Event: { //Not defined in the standard thus far, so not implemented
            registerEvent: function(event, listener, component){
                return null;
            },
            triggerEvent: function(event){
                return null;
            },
            removeEvent: function(event, listener){
                return null;
            }
        },
        namespace: function(name){
            var parts = name.split(".");
            var result = window;
            while (parts.length) {
                var part = parts.shift();
                result = result[part] = result[part] || {};
            }
            return result;
        },
		registerUnloadEvent: function(){
			Util.addEvent(window,"beforeunload",MPage.fireUnload);
		},
		registerResizeEvent: function(){
			Util.addEvent(window,"resize", MPage.fireResize);
		},
        fireResize: function(){
            var tempComp;
            var x;
            
            for (x = MPage._Components.length; x--;) {
                tempComp = MPage._Components[x];
                compContainer = tempComp.getTarget();
                tempComp.resize($(compContainer).width(), $(compContainer).height());
            }
        },
        fireUnload: function(){
            var x;
            for (x = MPage._Components.length; x--;) {
                MPage._Components[x].unload();
            }
        },
        addCustomComp: function(compObj){
            MPage._Components.push(compObj);
        },
		getCustomComp: function(compId){
			var tempComp;
            var x;
			
			for (x = MPage._Components.length; x--;) {
            	tempComp = MPage._Components[x];
               	if(tempComp.getComponentUid() === compId){
					return tempComp;
				}
            }
			return null;
		}
    };
}

MPage.Component = function(){
    this.baseclassSpecVersion = 1.0;
	this.componentMinimumSpecVersion = 1.0;
};

/* Initialize the component internal variables prior to loading data or rendering.  
 * The component should NOT attempt to render during the init() subroutine as the DOM element may not exist.
 */
MPage.Component.prototype.init = function(){
    //Leave empty so component developers can override if necessary
};

MPage.Component.prototype.generate = function(target, callback, options){
    var combined;
    var funcCallback;
    
	//Get the target if it is not already defined. (Should already be set)
    if (!target) {
        target = this.getTarget();
    }
    
	if (typeof this.getOption("errMsg") === "string") {
		MP_COMMON.RunErrorComponent(this,{"description":this.getOption("errMsg")});
		return this;
	}
	
	//Create a callback if not already defined.  (Should already be set)
    if (!callback) {
        funcCallback = function(component){
            component.render();
			var pComp = component.getOption("parentComp");
			if (pComp.subLabel == "") {
				pComp.updateSubLabel("");
			}
        };
    }
    else {
        funcCallback = function(component){
            component.render();
            callback(component);
        };
    }
    
	//If options are available, combine them with the existing options
    if (options) {
        combined = {};
        combined = this.options;
        for (attr in options) {
            combined[attr] = options[attr];
        }
        this.options = combined;
    }
    
	//Initialize the component
    this.init(options);
	//Load the data for the component
    this.loadData(funcCallback);
    return this;
};

MPage.Component.prototype.loadData = function(callback){
    //Prepare the callback for the loadCcl call
    var component = this;
    var funcCallback;
    funcCallback = function(response){
        component.data = response;
        callback(component);
    };
    
    //Check dataType
    if (this.cclDataType === "undefined") {
        this.cclDataType = "JSON";
    }
    
    //Call the cclProgram and run it with cclParams
    if (this.cclProgram && this.cclParams && (this.cclParams.length > 0)) {
        this.loadCCL(this.cclProgram, this.cclParams, funcCallback, this.cclDataType);
    }
    else {
        callback(component);
    }
};

MPage.Component.prototype.loadCCL = function(cclProgram, cclParams, callback, dataType){		
    var that = this;
    var info = null;
	var page_url = null;
    var tempData = null;
    var paramString = "";
    var x;
	if (location.href.match(/^http/))
	{
		page_url = [location.protocol,"//",location.host,location.pathname.replace(/\/[A-Za-z0-9\_]+$/,"/")].join("");
		try{
			// Firefox, Opera 8.0+, Safari
			info=new XMLHttpRequest();
		}
		catch (e){
			//Internet Explorer
			try{
				info=new ActiveXObject("Msxml2.XMLHTTP");
			}
			catch (e){
				info=new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
	}
	else
	{
		info = new XMLCclRequest();
	}
		
    info.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200) {
            try {
                //MP_Util.LogScriptCallInfo(null, this, "mp_custom_component_core.js", "loadCCL");
                //Need to interpret the data here and set into this.data
				if (typeof (that.debug) != "undefined" && that.debug !== null && that.debug) {
					window.open().document.write(this.responseText);
				}
                switch (dataType) {
                    case "XML":
						//MP_Util.WriteToFile(this.responseText);
                         if (window.ActiveXObject) {
							//for IE
							xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
							xmlDoc.async="false";
							xmlDoc.loadXML(this.responseText);
						} else if (document.implementation && document.implementation.createDocument) {
						//for Mozila
							parser=new DOMParser();
							xmlDoc=parser.parseFromString(this.responseText,"text/xml");
						}
						callback.call(that, xmlDoc);
                        break;
                    case "TEXT":
                        callback.call(that, this.responseText);
                        break;
                    case "JSON":
                    default:
                        callback.call(that, JSON.parse(this.responseText));
                        break;
                }
            } 
            catch (err) {
                MP_COMMON.RunErrorComponent(that, err);
            }
        }
    };
    
    //Ensure all strings are encapsulated in '', "", or ^^
    for (x = cclParams.length; x--;) {
        if (typeof cclParams[x] == "string") {
            if (!/^'.*'$/.test(cclParams[x]) && !/^".*"$/.test(cclParams[x]) && !/^\^.*\^$/.test(cclParams[x])) {
                cclParams[x] = "^" + cclParams[x] + "^";
            }
        }
        else 
            if (typeof cclParams[x] == "number") {
                if (!/\.0$/.test(cclParams[x])) {
                    cclParams[x] = cclParams[x] + ".0";
                }
            }
    }
	if (page_url)
	{
		page_url = [page_url,cclProgram,"?parameters=",encodeURIComponent(cclParams.join(","))].join("");
		info.open('GET', page_url, true);
		info.send(null);
	}
	else
	{
		info.open('GET', cclProgram, true); //set to false for sync call
		info.send(cclParams.join(","));
	}
};

/*default implementation of this which is only responsible for TEXT data*/
MPage.Component.prototype.render = function(){
    var target;
    if (typeof this.data === "string") {
        target = this.getTarget();
        target.innerHTML = this.data;
    }
};

MPage.Component.prototype.getOption = function(name){
    if (this.options && this.options[name]) {
        return this.options[name];
    }
    else {
        return null;
    }
};

MPage.Component.prototype.setOption = function(name, value){
    if (!this.options) {
        this.options = {};
    }
    this.options[name] = value;
};

MPage.Component.prototype.getProperty = function(name){
    if (this.properties && this.properties[name]) {
        return this.properties[name];
    }
    else 
        if (MPage.Properties[name]) {
            return MPage.Properties[name];
        }
        else {
            return 'undefined';
        }
};

MPage.Component.prototype.setProperty = function(name, value){
    if (this.properties) {
        this.properties[name] = value;
    }
    else {
        this.properties = {};
        this.properties[name] = value;
    }
	
	//Take special action depending on the property
	if("headerTitle|headerSubTitle|headerShowHideState".indexOf(name)  >= 0){
		var parentComp = this.getOption('parentComp');
		switch(name){
			case "headerTitle":
				parentComp.updateLabel(value);
				break;
			case "headerSubTitle":
				parentComp.updateSubLabel(value);
				break;
			case "headerShowHideState":
				parentComp.setExpandCollapseState(value);
				break;
		}
	}
	
    return this;
};

MPage.Component.prototype.getTarget = function(){
    var target = undefined;
    if (this.options && this.options['target']) {
		if (typeof this.options['target'] == "string")
			this.options['target'] = $(this.options['target']).get(0);
        target = this.options['target'];
    }
    return target;
};

MPage.Component.prototype.setTarget = function(target){
    if (this.options) {
        this.options['target'] = target;
    }
    else {
        this.options = {};
        this.options['target'] = target;
    }
};

MPage.Component.prototype.resize = function(width, height){
	return null;
};

MPage.Component.prototype.unload = function(){
    return null;
};

MPage.Component.prototype.getComponentUid = function(){
    return this.getOption('id');
};

MPage.Component.prototype.throwNewError = function(description, err){
    var error = err || new Error(description);
    throw (error);
};